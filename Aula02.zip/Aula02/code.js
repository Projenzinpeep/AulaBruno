
let c1 = "vermelho"
let c2 = "rosa"
let c3 = "amarelo"
let c4 = "branca"
let c5 = "verde"

//Formato JSON
const json = [
                {co1:"vermelho",cor2:"rosa",cor3:"amarelo",cor4:"branco",cor5:"verde"},
                {fr1:"morango",fr2:"laranja",fr3:"melão",fr4:"limãoneve",fr5:"abacate"}
             ]



const dados = [c1,c2,c3,c4,c5]

let cor ="amarelo"

for(let i=0;i<dados.length;i++){

    if(cor == dados[i]){
        console.log("Encontrou " + i)
        break
    } else{
        console.log("Não encontrou!")
    }

}




//console.log(dados.length)